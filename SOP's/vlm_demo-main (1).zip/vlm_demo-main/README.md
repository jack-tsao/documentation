# VLM Chat Interface - Launch Guide

This repository contains the split codebase for the VLM Chat Interface.

The project consists of three components:

- **Django Backend** – Handles communication between the frontend and AI model server.
- **FastAPI Model Server** – Hosts the Vision Language Model and performs inference.
- **React Frontend** – Provides the web interface for interacting with the model.

---

# Project Structure

```text
vlm_demo/
├── manage.py
├── vlm_backend/          # Django backend
│   └── vlm_backend/
│       └── settings.py
├── vlm_frontend/         # React frontend
└── vlm_model_server/     # FastAPI model server
    ├── model_server.py
    └── vlm_service.py
```

---

# Documentation Index

For detailed architectural, optimization, and setup information, please refer to the following documents:

- **[VLM System Architecture & Performance Optimization History](./VLM%20System%20Architecture%20&%20Performance%20Optimization%20History.md)**: A complete overview of the three-tier architecture and the 9-phase optimization journey that brought latency down from 70s to 8s.
- **[Model Machine Setup & vLLM Guide](./vlm_model_server/README.md)**: Instructions for serving the model via vLLM on x86 hardware with GPTQ 4-bit quantization and custom Jinja templates.
- **[Frontend Design & Implementation](./vlm_frontend/README.md)**: Details the aesthetic philosophy, component structure, state management, and WebGL integrations of the React/Vite interface.
- **[ARM/Jetson Installation Guide](./README-Machine_Setup.md)**: Reference guide for installing the PLaMo environment on ARM-based NVIDIA Jetson devices, including custom compilation steps for `causal-conv1d` and `mamba-ssm`.

---

# Initial Configuration

Before launching the project, two configuration values must be updated.

## 1. Configure the Model Server IP

Open:

```text
vlm_backend/vlm_backend/settings.py
```

Near the bottom of the file, update:

```python
MODEL_SERVER_URL = "http://<MODEL_MACHINE_IP>:8001"
```

Replace `<MODEL_MACHINE_IP>` with the IP address of the machine running the AI model.

**This change must be made on both:**

- The machine running the AI model.
- The machine running the Django backend and frontend.

---

## 2. Configure the Local Model Path

Open:

```text
vlm_model_server/vlm_service.py
```

Near the top of the file, update:

```python
MODEL_PATH_OR_ID = "/path/to/local/model"
```

Set this to the local directory containing the AI model.

This only needs to be changed on the machine hosting the AI model.

---

# Launching the AI Model Server

On the machine running the AI model:

Activate the project's Python virtual environment:

```bash
source /media/ubuntu/709758c3-db42-4feb-ba48-961b555f4eb8/vlm_demo/vlm_model_server/my_project/venv/bin/activate
```

Navigate to the model server directory:

```bash
cd vlm_model_server
```

Start the FastAPI model server:

```bash
uvicorn model_server:app --host 0.0.0.0 --port 8001
```

The model server will begin loading the AI model. Wait until startup is complete before launching the backend.

---

# Launching the Django Backend

On the machine hosting the backend:

Open a terminal in the `vlm_demo` directory and run:

```bash
python3 manage.py runserver 0.0.0.0:8000
```

---

# Launching the Frontend

On the backend machine, open a second terminal.

Navigate to the frontend directory:

```bash
cd vlm_frontend
```

Start the development server:

```bash
npm run dev
```

---

# Accessing the Application

Open a web browser and navigate to:

```
http://localhost:5173
```

The frontend will communicate with the Django backend, which forwards inference requests to the AI model server.

---

# Startup Order

Always launch the components in the following order:

1. Configure `MODEL_SERVER_URL` and `MODEL_PATH_OR_ID`.
2. Start the AI Model Server.
3. Start the Django Backend.
4. Start the React Frontend.
5. Open `http://localhost:5173` in your web browser.
