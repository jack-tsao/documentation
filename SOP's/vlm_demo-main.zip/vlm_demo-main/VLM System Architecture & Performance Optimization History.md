# VLM System Architecture & Performance Optimization History

This document provides an overview of the VLM Chat Interface architecture, the optimization process undertaken to improve inference performance on the NVIDIA Jetson Orin (AIR-030), and the final production configuration.

---

# System Architecture

The VLM Chat Interface is divided into three independent services to separate the user interface from GPU-intensive inference tasks.

```
                React Frontend
                      │
                      ▼
              Django Backend
                      │
                      ▼
          FastAPI Model Server
                      │
                      ▼
        PLaMo-2.1-2B Vision Language Model
```

## Frontend (React / Vite)

The frontend is responsible for:

- Displaying the web interface
- Capturing user prompts
- Displaying bounding boxes
- Managing user interaction

Translation requests are handled on the frontend before being sent to the backend, reducing unnecessary processing on the server.

---

## Django Backend

The Django backend acts as the middleware between the frontend and the model server.

Responsibilities include:

- Receiving requests
- Queueing inference jobs
- Forwarding requests to the model server
- Parsing returned coordinates
- Scaling coordinates back to the original image resolution
- Returning formatted results to the frontend

No machine learning inference occurs inside Django.

---

## FastAPI Model Server

The FastAPI server hosts the Vision Language Model.

Responsibilities include:

- Loading the PLaMo-2.1-2B-VL model
- Preprocessing images
- Running GPU inference
- Returning generated bounding box coordinates

Keeping inference isolated prevents PyTorch memory allocation and CUDA contexts from interfering with the Django web workers.

---

# Performance Optimization History

The original implementation required approximately **70 seconds** to generate a single bounding box.

The following optimizations were implemented to reduce latency.

---

## Phase 1 — Image Downscaling

### Problem

High-resolution images produced an excessive number of visual tokens, overwhelming the Jetson Orin GPU.

### Solution

Input images were resized before inference using:

```python
image.thumbnail((448, 448))
```

Later this was refined to use the SigLIP2 native image size of **384×384**.

### Result

Latency decreased modestly while maintaining accurate bounding box predictions.

---

## Phase 2 — Triton Warmup

### Problem

PyTorch compiled CUDA kernels during the first inference request, causing major startup delays.

### Solution

The warmup routine was rewritten to process a dummy image during server startup.

Additionally:

```python
torch.compile(model)
```

was introduced to fuse compatible operations into optimized CUDA kernels.

### Result

Cold-start latency disappeared.

Overall inference time remained roughly **69 seconds**.

---

## Phase 3 — Profiling the Pipeline

### Problem

It was unclear whether inference or image post-processing was responsible for the latency.

### Solution

Detailed timing metrics were added throughout the pipeline.

Measured timings included:

| Operation | Time |
|-----------|------|
| Draw Bounding Box | ~0.0015 s |
| Base64 Encoding | ~0.005 s |
| Total Model Generation | ~70 s |

### Result

Post-processing accounted for less than 10 milliseconds.

The bottleneck was confirmed to be entirely within model inference.

---

## Phase 4 — Prefill vs. Decoding Analysis

### Problem

The Hugging Face `generate()` function hides both image processing and token generation inside a single call.

### Solution

A custom `TimingLogitsProcessor` was added to record token generation timestamps.

Measured timings:

| Stage | Time |
|--------|------|
| Image Preprocessing | 0.23 s |
| Time to First Token | 3.78 s |
| Token Decoding | 66.2 s |
| Tokens Generated | 19 |

### Result

The Vision Encoder completed in under four seconds.

The remaining time was spent decoding text.

Average decode speed:

```
3.48 seconds per token
```

---

## Phase 5 — 8-bit Quantization

### Problem

Memory pressure suggested paging might be slowing decoding.

### Solution

The model was loaded using:

```
load_in_8bit=True
```

via BitsAndBytes.

### Result

The server failed during startup.

Current ARM builds of BitsAndBytes lacked the CUDA symbols required by JetPack.

The change was reverted.

---

## Phase 6 — KV Cache Investigation

### Observation

The image processing time and per-token decoding time were almost identical.

This suggested the image was being reprocessed during every decoding step.

### Solution

The following option was forced during generation:

```python
use_cache=True
```

### Result

The model's KV cache became active.

Total inference time dropped dramatically.

| Before | After |
|---------|------:|
| ~70 s | ~8 s |

This proved to be the single largest optimization.

---

## Phase 7 — Mamba Graph Optimization

### Problem

PLaMo combines Transformers with Mamba State Space Models.

Attempting to compile the model caused numerous graph breaks.

### Solution

Graph breaks were analyzed using:

```
TORCH_LOGS="graph_breaks"
```

PyTorch compilation was tuned with:

- `mode="reduce-overhead"`
- `fullgraph=False`

### Result

Inference decreased from approximately

```
8.0 s → 4.89 s
```

---

## Phase 8 — Hybrid Quantization

### Problem

The model continued to consume excessive GPU memory.

Conventional INT8 quantization significantly degraded Mamba accuracy.

### Solution

An offline hybrid quantization pipeline was implemented.

- GPTQ applied to Transformer layers
- Quamba2 applied to Mamba layers

Calibration dataset:

```
lmms-lab/RefCOCO
```

### Result

- 50% memory reduction
- Final latency:

```
4.77 seconds
```

while maintaining identical coordinate accuracy.

---

## Phase 9 — TensorRT Evaluation

TensorRT integration was investigated for the SigLIP Vision Encoder.

However, PLaMo tightly couples vision embeddings with dynamic text sequence expansion.

Extracting the encoder would require:

- custom CUDA memory management
- hard-coded sequence lengths
- fragile PyCUDA integration

Estimated improvement:

```
≈100 ms
```

Given the maintenance burden, TensorRT integration was abandoned.

---

# Final Production Optimizations

The production system currently uses:

- Maximum Jetson power mode (`nvpmodel -m 0`)
- `jetson_clocks`
- TensorFloat-32 (TF32)
- CuDNN Benchmarking
- Input downscaling
- Shape-synchronized warmup
- `torch.compile`
- KV caching (`use_cache=True`)

These optimizations reduced inference latency from:

| Initial | Final |
|---------:|------:|
| ~70 s | ~8 s |

Further experimental work reduced latency to approximately **4.8 seconds**, although that configuration is not currently deployed.

---

# Production Libraries

## Frontend

- React
- Vite
- Axios
- i18next
- react-i18next
- OGL

---

## Django Backend

- requests
- opencv-python
- deep-translator

---

## Model Server

- PyTorch
- Transformers
- Accelerate
- FastAPI
- Uvicorn
- Pillow
- python-multipart

> **Note**
>
> BitsAndBytes and TorchAO were evaluated during development but are not used in production due to compatibility issues with the custom PLaMo Mamba architecture.
