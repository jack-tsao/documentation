import requests
import time
import os
import sys

# Default settings
SERVER_URL = "http://127.0.0.1:8001/inference"
DEFAULT_IMAGE_PATH = "test_image.jpg"
DEFAULT_PROMPT = "Find the object"

def run_test():
    # Allow passing image path and prompt via command line
    image_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_IMAGE_PATH
    prompt = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_PROMPT

    if not os.path.exists(image_path):
        print(f"[Error] Test image not found at '{image_path}'.")
        print("Usage: python test_bbox_iou.py <path_to_clean_image.jpg> \"Find the <object>\"")
        sys.exit(1)

    print(f"--- Triggering Model Load ---")
    try:
        requests.post("http://127.0.0.1:8001/load")
    except Exception as e:
        print(f"Failed to trigger load: {e}")
        
    print(f"--- Waiting for Model to Load ---")
    while True:
        try:
            status = requests.get("http://127.0.0.1:8001/status").json()
            if status.get("loading_status") == "loaded" or status.get("status") == "ready":
                print("Model is fully loaded!")
                break
            time.sleep(2)
        except Exception as e:
            print(f"Error checking status: {e}")
            time.sleep(2)

    print(f"\n--- Running Test ---")
    print(f"Image: {image_path}")
    print(f"Prompt: '{prompt}'")
    
    start_time = time.time()
    
    with open(image_path, 'rb') as f:
        files = {'file': (os.path.basename(image_path), f, 'image/jpeg')}
        data = {'prompt': prompt}
        
        try:
            response = requests.post(SERVER_URL, files=files, data=data, timeout=120)
            response.raise_for_status()
            
            result = response.json()
            end_time = time.time()
            
            print("\n[Result Data]")
            if "text" in result:
                print(result["text"])
            else:
                print(f"Server returned: {result}")
            
            print("\n[Timings]")
            timings = result.get("timings", {})
            for k, v in timings.items():
                print(f"  {k}: {v:.3f}s")
                
            print(f"\nTotal script time: {end_time - start_time:.3f}s")
            
        except Exception as e:
            print(f"[Error] Inference failed: {e}")

if __name__ == "__main__":
    run_test()
