import os
import shutil
import tempfile
import time
from fastapi import FastAPI, UploadFile, Form, File, HTTPException
from fastapi.responses import JSONResponse
import vlm_service

app = FastAPI(title="VLM Inference API")

@app.get("/status")
def get_status():
    """Returns the loading status of the VLM model."""
    status_info = vlm_service.get_model_status()
    return JSONResponse(content=status_info)

@app.post("/load")
def load_model():
    """Triggers the VLM background loading thread."""
    vlm_service.load_model_async()
    return JSONResponse(content={
        "status": "success",
        "message": "VLM model loading process initiated successfully."
    })

@app.post("/unload")
def unload_model():
    """Triggers complete unloading of the VLM model from host and device memory."""
    vlm_service.unload_model()
    return JSONResponse(content={
        "status": "success",
        "message": "VLM model successfully unloaded."
    })

@app.post("/inference")
async def inference(prompt: str = Form(...), file: UploadFile = File(...)):
    """
    Accepts an image file and a prompt, runs VLM inference, and returns detections.
    """
    if not prompt:
        raise HTTPException(status_code=400, detail="No prompt text provided")
    
    t_start = time.time()
    
    # Save the uploaded file to a temporary location
    try:
        suffix = os.path.splitext(file.filename)[1]
        if not suffix:
            suffix = ".jpg"
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
            shutil.copyfileobj(file.file, temp_file)
            temp_file_path = temp_file.name
            
        # Run inference using the existing service
        result = vlm_service.run_vlm_inference(temp_file_path, prompt)
        
    finally:
        # Clean up temporary file
        if 'temp_file_path' in locals() and os.path.exists(temp_file_path):
            os.remove(temp_file_path)

    t_end = time.time()
    if isinstance(result, dict) and "timings" in result:
        result["timings"]["model_server_total_time"] = t_end - t_start
    elif isinstance(result, dict):
        result["timings"] = {"model_server_total_time": t_end - t_start}

    return JSONResponse(content=result)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
