# Model Machine: VLM Serving & Optimization Guide

This guide describes how to configure, optimize, and launch the **PLaMo-2.1-8B-VL** or **PLaMo-2.1-2B-VL** model on the dedicated GPU server using the vLLM plugin environment.

> **Disclaimer**: This documentation describes an x86 setup. Although Jetson hardware was explored (and compilation steps are provided below), the primary optimized deployment strategy relies on Intel x86 workstations with dedicated GPUs running vLLM.

---

## 1. Environment Setup

On the GPU machine, ensure you have the `vllm_plamo2` plugin installed within a clean virtual environment:

```bash
# 1. Run the environment preparation script
./setup_plamo_vllm_env.sh

# 2. Activate the environment
source .plamo_vllm/bin/activate
```

---

## 2. Model Quantization (12GB GPU Optimization)

Serving the FP16/BF16 weights of the **PLaMo 2.1-8B-VL** model requires **20GB+ of VRAM** (as documented in the plugin README). To fit this model within a **12GB GPU**, you must run the model quantized.

We recommend using **GPTQ 4-bit weight quantization** coupled with **FP8 or INT8 KV cache quantization**.

### Serving Command with GPTQ & KV Cache Quantization:
```bash
VLLM_PLAMO2_PLUGIN_ENABLE_VL=1 vllm serve /path/to/plamo-2.1-8b-vl \
  --trust-remote-code \
  --port 8000 \
  --served-model-name plamo2vl \
  --max-model-len 4096 \
  --max-num-seqs 1 \
  --gpu-memory-utilization 0.90 \
  --quantization gptq \
  --kv-cache-dtype fp8
```
*Adjust `--gpu-memory-utilization` depending on whether other processes share the GPU.*

---

## 3. Automating Image Token Wrapping (Jinja Chat Template)

When serving a Vision-Language Model like PLaMo 2.1-VL, the vLLM endpoint needs to translate standard OpenAI-compatible messages into a prompt format that contains the `<plamo:image>` special token.

Because the `vllm_plamo2` plugin uses `PromptReplacement` matching the literal target `"<plamo:image>"`, the Jinja template **must** output `"<plamo:image>"` once for each incoming image.

### Custom Jinja Chat Template (`plamo_vl.jinja`)
Save the following Jinja template code on the model machine (e.g. as `plamo_vl.jinja`):

```jinja
{{ bos_token }}
{%- for message in messages %}
  {%- if message.role == 'user' %}
    {{- 'User: ' -}}
    {%- for content in message.content %}
      {%- if content.type == 'image_url' or content.type == 'image' %}
        {{- '<plamo:image>' -}}
      {%- elif content.type == 'text' %}
        {{- content.text -}}
      {%- endif %}
    {%- endfor %}
    {{- '\n' -}}
  {%- elif message.role == 'assistant' %}
    {{- 'Assistant: ' + message.content + '\n' -}}
  {%- endif %}
{%- endfor %}
{%- if add_generation_prompt %}
  {{- 'Assistant: ' -}}
{%- endif %}
```

### Launching with the Custom Template:
Pass the path of the template file to the `--chat-template` parameter:

```bash
VLLM_PLAMO2_PLUGIN_ENABLE_VL=1 vllm serve /path/to/plamo-2.1-8b-vl \
  --trust-remote-code \
  --port 8000 \
  --served-model-name plamo2vl \
  --chat-template plamo_vl.jinja \
  --max-model-len 4096 \
  --max-num-seqs 1
```

---

## 4. Jetson & Edge Deployments: Concurrency & Fast Kernels

If migrating from an Intel x86 workstation to NVIDIA Jetson hardware:

1. **Compiling Kernels from Source**:
   - The PLaMo 2 architecture uses `mamba_ssm` and `causal_conv1d` for its hybrid Mamba-Attention layers.
   - Pre-built binary wheels are only shipped for x86 CUDA. On Jetson (ARM64 / aarch64), you **must** build these packages from source:
     ```bash
     # Install compilation dependencies
     pip install packaging rawpy
     
     # Clone and compile causal_conv1d
     git clone https://github.com/Dao-AILab/causal-conv1d.git
     cd causal-conv1d && pip install .
     
     # Clone and compile mamba
     git clone https://github.com/state-spaces/mamba.git
     cd mamba && pip install .
     ```
2. **Fast Kernel Sanity Check**:
   - If compilation fails, the model falls back to a naive PyTorch implementation which is **5x to 10x slower**.
   - Verify the fast CUDA kernels are active by running a small inference script and profiling GPU occupancy/tokens-per-second before scaling deployment.
