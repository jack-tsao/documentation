# VLM Integration Guide

This guide describes how to connect a production Vision-Language Model (VLM) such as **Qwen2-VL-2B-Instruct** or **PLaMo-2.1-2B-VL** to the `vlm_demo` Django backend.

---

## 1. System Requirements & Setup

To run a VLM locally on a GPU with CUDA support, ensure you have the following installed:

### Required Python Packages
Install the required deep learning and model loader libraries:
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121  # Adjust for your CUDA version
pip install transformers accelerate pillow django django-cors-headers
```

### Hardware Considerations
- **GPU (Recommended)**: NVIDIA GPU with at least 8GB VRAM for 2B models (e.g., Qwen2-VL-2B, Plamo-2.1-2B-VL) or 16GB+ VRAM for 7B models.
- **CPU (Fallback)**: Possible but extremely slow (30-60+ seconds per keyframe analysis).

---

## 2. Code Architecture Overview

The backend uses a multi-threaded service manager to handle weight-loading and execution:

```mermaid
graph TD
    A[Django App Ready Event] -->|Triggers| B[vlm_service.load_model_async]
    B -->|Starts Thread| C[Background Model Loading]
    C -->|Auto-Detect Device| D{GPU Available?}
    D -->|Yes| E[Load Weights to CUDA]
    D -->|No| F[Load Weights to CPU / Fallback]
    
    G[React Client] -->|POST /vlm/analyze/| H[analyze view]
    H -->|Creates task| I[TASKS_DB]
    G -->|Polls GET /vlm/result/taskId/| J[get_result view]
    J -->|Calls| K[vlm_service.run_vlm_inference]
    K -->|HuggingFace Inference| L[Processor & Model forward pass]
    L -->|Output text| M[Parse Bounding Boxes]
    M -->|PIL Overlay| N[Save Processed Image to Media]
    N -->|Returns Response| G
```

The model functions are contained inside:
- [vlm_service.py](file:///c:/Users/sacii/Downloads/VLM%20Model%20Chat%20Interface_v2/vlm_demo/vlm_backend/inference/vlm_service.py): Manages in-memory weight storage, loading states, and runs the tokenization/inference/coordinate parsing loop.
- [apps.py](file:///c:/Users/sacii/Downloads/VLM%20Model%20Chat%20Interface_v2/vlm_demo/vlm_backend/inference/apps.py): Eagerly spins up the model loading thread when the Django server initializes.
- [views.py](file:///c:/Users/sacii/Downloads/VLM%20Model%20Chat%20Interface_v2/vlm_demo/vlm_backend/inference/views.py): Queries status logs and pipes keyframe paths into the inference engine.

---

## 3. Connecting Your Model (Hugging Face Integration)

To connect an actual Hugging Face model, follow these two steps:

### Step 3.1: Configure Model Identifiers
Open [vlm_service.py](file:///c:/Users/sacii/Downloads/VLM%20Model%20Chat%20Interface_v2/vlm_demo/vlm_backend/inference/vlm_service.py) and change:
```python
MODEL_PATH_OR_ID = "Qwen/Qwen2-VL-2B-Instruct"  # Or your local weights path
```

### Step 3.2: Enable the Transformers Loader
Modify the background loading thread inside `_load_model_thread()` by uncommenting the loader statements:

```python
# vlm_service.py: line 84
# --- REAL INTEGRATION HOOK ---
processor = AutoProcessor.from_pretrained(MODEL_PATH_OR_ID)
model = AutoModelForVision2Seq.from_pretrained(
    MODEL_PATH_OR_ID, 
    torch_dtype=torch.float16 if "cuda" in _device else torch.float32,
    device_map="auto" if "cuda" in _device else None
)

with _status_lock:
    _model = model
    _processor = processor
```

---

## 4. Input Prompting & Output Coordinates

### Formatted Prompting
Vision-language models require images and text to be wrapped in conversational tokens. Here is a typical template for Qwen2-VL:

```python
# Prepare prompt using processor templates
messages = [
    {
        "role": "user",
        "content": [
            {"type": "image", "image": image},
            {"type": "text", "text": prompt},
        ],
    }
]
text = _processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
inputs = _processor(text=[text], images=[image], padding=True, return_tensors="pt")
```

### Coordinate Parsing
Many state-of-the-art VLMs output localized object coordinate strings directly in their responses. For example:
- **Qwen2-VL** formats coordinates as: `<box>[ymin, xmin, ymax, xmax]</box>` normalized to a scale of `1000`.
- The regular expression parser `_parse_vlm_coordinates()` is fully configured in `vlm_service.py` to:
  1. Detect bracketed arrays containing 4 digits.
  2. Auto-detect coordinate range scale (detecting if coordinates are normalized to `1000` or represented as floats `0.0 - 1.0`).
  3. Translate coordinates into absolute pixel locations: `{"x": xmin, "y": ymin, "w": width, "h": height}` relative to the original image canvas.
  4. Pass coordinates to Pillow for real-time red box visualization drawing before saving the inference keyframe to the `/media/processed/` static directory.

---

## 5. Production Optimization Best Practices

1. **Celery Task Queues**: 
   For high-traffic applications, do not run model inference synchronously inside the HTTP polling view. Move `run_vlm_inference` inside a Celery task queue (using `redis` or `rabbitmq` as a broker) with a dedicated GPU worker pool.
2. **Weight Quantization**: 
   To fit model weights onto lower-end graphics cards (e.g. 4GB or 6GB VRAM), import the model in 8-bit or 4-bit precision using `bitsandbytes`:
   ```python
   from transformers import BitsAndBytesConfig
   quant_config = BitsAndBytesConfig(load_in_4bit=True)
   model = AutoModelForVision2Seq.from_pretrained(
       MODEL_PATH_OR_ID, 
       quantization_config=quant_config
   )
   ```
3. **Lock CPU Threads**:
   By default, PyTorch can consume all available CPU cores when doing image conversions. Cap this behavior at startup:
   ```python
   import torch
   torch.set_num_threads(4)
   ```
