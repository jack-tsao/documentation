import os
import time
import uuid
import requests
import io
import threading
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
from PIL import Image, ImageDraw, ImageFont
from deep_translator import GoogleTranslator
from concurrent.futures import ThreadPoolExecutor

# Global executor for background translation/processing
_executor = ThreadPoolExecutor(max_workers=4)


# Global in-memory task database for development simulation
TASKS_DB = {}

# Persistent HTTP session for model requests
VLM_HTTP_SESSION = requests.Session()
VLM_INFERENCE_LOCK = threading.Lock()

@csrf_exempt
def model_status(request):
    """
    Returns the loading status of the VLM model from the standalone Model Server.
    """
    try:
        response = requests.get(f"{settings.MODEL_SERVER_URL}/status", timeout=5)
        return JsonResponse(response.json())
    except requests.exceptions.RequestException as e:
        return JsonResponse({
            "status": "error",
            "progress": 0,
            "model_loaded": False,
            "device": "unknown",
            "model_name": "PLaMo 2.1-2B-VL",
            "error": f"Model server is unreachable: {str(e)}"
        })

@csrf_exempt
def load_model_endpoint(request):
    """
    Triggers the VLM background loading thread on the standalone Model Server.
    """
    if request.method != "POST":
        return JsonResponse({"error": "Only POST requests allowed"}, status=405)
        
    try:
        response = requests.post(f"{settings.MODEL_SERVER_URL}/load", timeout=5)
        return JsonResponse(response.json())
    except requests.exceptions.RequestException as e:
        return JsonResponse({"error": f"Failed to connect to model server: {str(e)}"}, status=500)

@csrf_exempt
def unload_model_endpoint(request):
    """
    Triggers complete unloading of the VLM model on the standalone Model Server.
    """
    if request.method != "POST":
        return JsonResponse({"error": "Only POST requests allowed"}, status=405)
        
    try:
        response = requests.post(f"{settings.MODEL_SERVER_URL}/unload", timeout=10)
        return JsonResponse(response.json())
    except requests.exceptions.RequestException as e:
        return JsonResponse({"error": f"Failed to connect to model server: {str(e)}"}, status=500)

def run_vlm_inference_background(task_id, file_path, file_bytes, prompt, timestamp, filename, base_uri):
    """
    Background worker that runs the VLM inference synchronously 
    and updates the TASKS_DB with the final status.
    """
    task = TASKS_DB.get(task_id)
    if not task:
        return

    t_received = task.get("t_received", time.time())

    scenario = "VLM Detection Inference"
    is_image = filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))
    is_video = filename.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm'))
    
    detections = []
    vlm_response = ""
    img = None
    timings = {}
    
    try:
        if is_image and file_bytes:
            img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
        elif is_image and file_path and os.path.exists(file_path):
            img = Image.open(file_path).convert("RGB")
        elif is_video and os.path.exists(file_path):
            import cv2
            cap = cv2.VideoCapture(file_path)
            if timestamp is not None and timestamp != "null":
                try:
                    ts_msec = float(timestamp) * 1000
                    cap.set(cv2.CAP_PROP_POS_MSEC, ts_msec)
                except ValueError:
                    pass
            ret, frame = cap.read()
            cap.release()
            if ret:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame_rgb)
        
        if img is None:
            # Fallback if extraction failed
            img = Image.new("RGB", (640, 480), color="#1e293b")
            
        with VLM_INFERENCE_LOCK:
            t_lock_acquired = time.time()
            print(f"[PROFILE] [{task_id}] Lock acquired at {t_lock_acquired:.3f} (Wait: {t_lock_acquired - t_received:.3f}s since received)")

            # Optimization: Send ONLY the extracted frame over the network to the Model Machine
            img_byte_arr = io.BytesIO()
            img.save(img_byte_arr, format='JPEG')
            img_byte_arr.seek(0)
            
            files = {'file': ('frame.jpg', img_byte_arr, 'image/jpeg')}
            data = {'prompt': prompt}


            
            t_req_sent = time.time()
            print(f"[PROFILE] [{task_id}] Request sent to model server at {t_req_sent:.3f} (Prep time: {t_req_sent - t_lock_acquired:.3f}s)")
            
            response = VLM_HTTP_SESSION.post(f"{settings.MODEL_SERVER_URL}/inference", data=data, files=files, timeout=180)
            
            t_resp_received = time.time()
            print(f"[PROFILE] [{task_id}] Response received at {t_resp_received:.3f} (GPU/Network time: {t_resp_received - t_req_sent:.3f}s)")
            
            if response.ok:
                inference_result = response.json()
                vlm_response = inference_result.get("vlm_response", "No response.")
                detections = inference_result.get("detections", [])
                timings = inference_result.get("timings", {})

            else:
                vlm_response = f"System Error: Model Server returned {response.status_code} - {response.text}"
                
    except Exception as e:
        vlm_response = f"System Error: Failed to contact Model Server. {str(e)}"
        if img is None:
            img = Image.new("RGB", (640, 480), color="#ef4444")
            
    try:
        vlm_response_en = vlm_response
        
        def process_image(image, det_list):
            t0 = time.time()
            # Draw boxes
            draw = ImageDraw.Draw(image)
            if det_list:
                for det in det_list:
                    x, y, box_w, box_h = det["x"], det["y"], det["w"], det["h"]
                    draw.rectangle([x, y, x + box_w, y + box_h], outline="red", width=5)
                    label = f"{det.get('label', 'Target')} ({int(det.get('confidence', 0.9)*100)}%)"
                    draw.text((x, max(0, y - 20)), label, fill="red")
            
            t1 = time.time()
            import base64
            buffered = io.BytesIO()
            image.save(buffered, format="JPEG")
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
            t2 = time.time()
            
            return {
                "image_data": f"data:image/jpeg;base64,{img_str}",
                "draw_time": t1 - t0,
                "encode_time": t2 - t1
            }

        # Submit task concurrently
        future_image = _executor.submit(process_image, img, detections)
        
        # Wait for image processing (translation is offloaded to frontend)
        vlm_response_ja = None
        img_result = future_image.result()
        image_url = img_result["image_data"]
        
        timings["post_process_draw_time"] = img_result["draw_time"]
        timings["post_process_encode_time"] = img_result["encode_time"]

        t_postproc_done = time.time()
        total_backend_time = t_postproc_done - t_received
        
        print(f"[PROFILE] [{task_id}] Post-processing done at {t_postproc_done:.3f} (Post-proc time: {t_postproc_done - locals().get('t_resp_received', locals().get('t_lock_acquired', t_received)):.3f}s)")
        print(f"[PROFILE] [{task_id}] Total Backend Time: {total_backend_time:.3f}s")
        
        timings["total_backend_time"] = total_backend_time

        # Save to status cache
        task.update({
            "status": "completed",
            "scenario": scenario,
            "vlm_response": vlm_response,
            "vlm_response_en": locals().get('vlm_response_en', vlm_response),
            "vlm_response_ja": locals().get('vlm_response_ja', vlm_response),
            "image_url": image_url,
            "detections": detections,
            "timings": timings
        })
        t_complete = time.time()
        print(f"[PROFILE] [{task_id}] Task fully complete.")
        print(f"[PROFILE] [{task_id}] Task marked complete at {t_complete:.3f} (Total backend time: {t_complete - t_received:.3f}s)")
    except Exception as e:
        task.update({
            "status": "failed",
            "error": str(e),
        })
    finally:
        # Clean up original file to optimize disk I/O
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass

@csrf_exempt
def analyze(request):
    """
    Initiates a VLM analysis task on uploaded video/image & text prompt.
    Returns a task ID for frontend polling.
    """
    if request.method != "POST":
        return JsonResponse({"error": "Only POST requests allowed"}, status=405)

    prompt = request.POST.get("prompt", "").strip()
    video_file = request.FILES.get("video")
    timestamp = request.POST.get("timestamp", None)

    if not prompt:
        return JsonResponse({"error": "No prompt text provided"}, status=400)
    if not video_file:
        return JsonResponse({"error": "No video file provided"}, status=400)

    # Save uploaded file for video, or keep in memory for images
    is_video = video_file.name.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm'))
    file_path = None
    file_bytes = None

    if is_video:
        uploads_dir = os.path.join(settings.MEDIA_ROOT, 'uploads')
        os.makedirs(uploads_dir, exist_ok=True)
        sanitized_name = f"{uuid.uuid4().hex[:8]}_{video_file.name}"
        file_path = os.path.join(uploads_dir, sanitized_name)
        with open(file_path, 'wb+') as destination:
            for chunk in video_file.chunks():
                destination.write(chunk)
    else:
        file_bytes = video_file.read()

    # Generate task details
    task_id = f"task_{uuid.uuid4().hex[:8]}"
    t_received = time.time()
    print(f"[PROFILE] [{task_id}] Image received. (Time: {t_received:.3f})")

    # Store task details in memory
    TASKS_DB[task_id] = {
        "status": "processing",
        "prompt": prompt,
        "filename": video_file.name,
        "vlm_response_en": None,
        "vlm_response_ja": None, 
        "vlm_response": None,
        "file_path": file_path,
        "timestamp": timestamp,
        "t_received": t_received,
    }
    
    base_uri = request.build_absolute_uri('/')
    threading.Thread(
        target=run_vlm_inference_background,
        args=(task_id, file_path, file_bytes, prompt, timestamp, video_file.name, base_uri),
        daemon=True
    ).start()

    return JsonResponse({
        "status": "success",
        "taskId": task_id,
        "message": "Inference task initiated successfully"
    })

@csrf_exempt
def get_result(request, task_id):
    """
    Returns task completion status and reasoning output with processed keyframe image.
    Uses the standalone Model Server for inference over HTTP.
    """
    task = TASKS_DB.get(task_id)
    if not task:
        return JsonResponse({"error": "Task not found"}, status=404)

    if task.get("status") == "completed":
        return JsonResponse({
            "status": "completed",
            "scenario": task["scenario"],
            "vlm_response_en": task["vlm_response_en"], # Send English variant
            "vlm_response_ja": task["vlm_response_ja"], # Send Japanese variant
            "image_url": task["image_url"],
            "detections": task["detections"],
            "timings": task.get("timings", {})
        })
    elif task.get("status") == "failed":
        return JsonResponse({
            "status": "failed",
            "error": task.get("error", "Background execution failed")
        })
    else:
        return JsonResponse({"status": "processing"})

@csrf_exempt
def translate_text(request):
    """
    On-the-fly translation endpoint for the frontend
    """
    if request.method != "POST":
        return JsonResponse({"error": "Only POST requests allowed"}, status=405)
    
    text = request.POST.get("text", "").strip()
    source_lang = request.POST.get("source_lang", "auto")
    target_lang = request.POST.get("target_lang", "en")
    
    if not text:
        return JsonResponse({"translation": ""})
        
    try:
        translation = GoogleTranslator(source=source_lang, target=target_lang).translate(text)
        return JsonResponse({"translation": translation})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
