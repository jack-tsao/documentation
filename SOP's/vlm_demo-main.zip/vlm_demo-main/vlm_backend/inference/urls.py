from django.urls import path
from . import views

urlpatterns = [
    path("model-status/", views.model_status, name="model_status"),
    path("analyze/", views.analyze, name="analyze"),
    path("result/<str:task_id>/", views.get_result, name="get_result"),
    path("load/", views.load_model_endpoint, name="load_model"),
    path("unload/", views.unload_model_endpoint, name="unload_model"),
    path("translate/", views.translate_text, name="translate_text"),
]