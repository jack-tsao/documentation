# Installing the PLaMo Environment on ARM Systems

## Target Machine Specifications
The primary testing and validation machine for the x86 deployment featured the following specifications:
- **GPU:** RTX A2000 12GB VRAM
- **Storage:** 1 TB SSD
- **CPU:** Intel 13th Gen i5-13500E
- **OS/Architecture:** x86 Architecture (Persistence M)

> **Note on Jetson Hardware:** The instructions below largely focus on compiling the custom kernels required to run the PLaMo environment on NVIDIA Jetson ARM devices (specifically the AIR-030). Be aware that our final production environment targets x86 systems (see the model server documentation), but the ARM compilation steps are preserved here for reference.

Some of the libraries required by PLaMo are not fully compatible with ARM-based systems, such as the AIR-030. As a result, the installation process differs significantly depending on the target hardware platform.

For **x86 systems**, installation is relatively straightforward and can generally be completed by following the instructions provided on the model's Hugging Face repository.

For **ARM-based systems**, such as the AIR-030, the setup process is considerably more complex and may require additional troubleshooting. Due to compatibility issues between several dependencies, installation can be time-consuming and may involve manual modifications beyond the standard installation procedure.

It is recommended that all Python dependencies be installed within a dedicated Python virtual environment (`venv`).

The commands below successfully produced a working environment in our development setup. However, they should be considered a reference implementation rather than a guaranteed installation procedure, as our installation required a significant amount of manual troubleshooting and not every intermediate step was documented.

A second set of installation commands, provided during development by Ryan, is included later in this document. These commands provide a useful starting point but were not sufficient to produce a fully functional environment in our testing without additional modifications.

> **Note**
>
> If you encounter issues that are not covered here, consult the relevant project documentation or seek assistance from a team member familiar with the setup. AI assistants can also be useful for troubleshooting, but be sure to specify your hardware platform (e.g., AIR-030, Jetson AGX Orin), operating system, CUDA version, Python version, and the exact error messages you are receiving.

---

## Required Library Versions

The following library versions are required for the PLaMo model used in this project.

| Library | Version |
|----------|---------|
| PyTorch | `2.8.0` |
| Transformers | `4.57.1` |
| Pillow | `12.1.1` |
| Mamba SSM | `2.3.0` |
| causal-conv1d | `1.6.0` |
| Numba | `0.64.0` |
| NumPy | `1.26.4` |

---

# Install System Dependencies

```bash
sudo apt update

sudo apt install -y \
    python3-pip \
    python3-dev \
    libopenblas-dev \
    build-essential \
    ninja-build \
    cuda-cupti-12-6

sudo apt install -y \
    libcusparselt-dev \
    cusparselt-cuda-12
```

---

# Install PyTorch

```bash
python3 -m pip install \
    torch==2.8.0 \
    torchvision==0.23.0 \
    --index-url=https://pypi.jetson-ai-lab.io/jp6/cu126
```

Verify the installation:

```bash
python3 -c "
import torch
print(torch.__version__)
print(torch.cuda.is_available())
print(torch.cuda.get_device_name(0))
"
```

Expected output:

```text
2.8.0
True
Orin
```

---

# Install Python Dependencies

```bash
python3 -m pip install \
    transformers==4.57.1 \
    pillow==12.1.1 \
    numpy==1.26.4 \
    numba==0.64.0 \
    accelerate \
    sentencepiece \
    protobuf \
    safetensors \
    einops
```

---

# Configure CUDA Environment

```bash
export CUDA_HOME=/usr/local/cuda
export PATH=/usr/local/cuda/bin:$PATH
export MAX_JOBS=4
```

---

# Configure the Virtual Environment

To successfully build the CUDA extensions required by `causal-conv1d` and `mamba-ssm`, modify the virtual environment's `bin/activate` script.

Replace the contents of:

```text
venv/bin/activate
```

with the following script:

```bash
# Paste the modified activate script here
```

*(The full activate script from above should be inserted here unchanged.)*

After replacing the script, deactivate and reactivate the virtual environment:

```bash
deactivate

source /media/ubuntu/709758c3-db42-4feb-ba48-961b555f4eb8/vlm_demo/vlm_model_server/my_project/venv/bin/activate
```

Verify that `LD_LIBRARY_PATH` has been updated:

```bash
echo $LD_LIBRARY_PATH
```

---

# Build and Install causal-conv1d

Clone the repository:

```bash
git clone https://github.com/Dao-AILab/causal-conv1d.git
cd causal-conv1d
```

Build and install:

```bash
python3 -m pip install .
```

Return to the previous directory:

```bash
cd ..
```

Verify the installation:

```bash
python3 -c "
import causal_conv1d
import causal_conv1d_cuda
print('SUCCESS')
"
```

Expected output:

```text
SUCCESS
```

---

# Build and Install Mamba

If installing `mamba-ssm` from PyPI results in Triton-related errors, it may be necessary to build the package from source.

Clone the repository:

```bash
git clone https://github.com/state-spaces/mamba.git
cd mamba
```

Force a source build:

```bash
export MAMBA_FORCE_BUILD=TRUE
python3 -m pip install .
```

Return to the previous directory:

```bash
cd ..
```

Verify the installation:

```bash
python3 -c "
import mamba_ssm
import mamba_ssm.ops.selective_scan_cuda
print('SUCCESS')
"
```

Expected output:

```text
SUCCESS
```

---

# Troubleshooting

Both `causal-conv1d` and `mamba-ssm` compile CUDA extensions during installation.

On Jetson-based ARM systems, the build process may fail because the compiler cannot locate PyTorch shared libraries (such as `libtorch_python.so`) or CUDA runtime libraries.

Updating the virtual environment's `activate` script to correctly configure `LD_LIBRARY_PATH` allows these libraries to be located during compilation. Once this environment variable is configured correctly, both CUDA extensions should compile successfully.

If you continue to experience issues, verify:

- CUDA is installed correctly.
- `CUDA_HOME` points to the correct CUDA installation.
- `LD_LIBRARY_PATH` includes the PyTorch `torch/lib` directory.
- The installed PyTorch version matches the CUDA version.
- You are using the correct Python virtual environment.



# Appendix A - Ryan's ARM Installation Procedure

The following installation procedure was provided during development as an alternative method for configuring an ARM-based system. These commands are preserved as a reference and may require modification depending on the target hardware, JetPack version, CUDA version, and installed software.

> **Note**
>
> This procedure did not produce a fully working environment in our development setup without additional troubleshooting. It is included as a reference only.

## Verify the System Configuration

```bash
python3 --version
cat /etc/nv_tegra_release
dpkg --print-architecture
```

---

## Install System Dependencies

```bash
sudo apt update

sudo apt install -y \
    python3-pip \
    python3-dev \
    libopenblas-dev \
    build-essential \
    ninja-build
```

---

## Upgrade pip and Build Tools

```bash
python3 -m pip install -U \
    pip \
    setuptools \
    wheel \
    packaging \
    ninja

python3 -m pip install --no-cache-dir numpy==1.26.1
```

---

## Install PyTorch

Navigate to your downloads directory:

```bash
cd ~/Downloads
```

Download the JetPack wheel:

```bash
wget -O torch_jp60.whl \
https://developer.download.nvidia.com/compute/redist/jp/v60/pytorch/torch-2.4.0a0+07cecf4168.nv24.05.14710581-cp310-cp310-linux_aarch64.whl
```

Rename the wheel:

```bash
mv torch_jp60.whl \
torch-2.4.0a0+07cecf4168.nv24.05.14710581-cp310-cp310-linux_aarch64.whl
```

Install PyTorch:

```bash
python3 -m pip install --no-cache-dir \
./torch-2.4.0a0+07cecf4168.nv24.05.14710581-cp310-cp310-linux_aarch64.whl
```

Verify the installation:

```bash
python3 -c "
import torch
print(torch.__version__)
print(torch.cuda.is_available())
print(torch.cuda.get_device_name(0))
"
```

---

## Install TorchVision

```bash
python3 -m pip install torchvision==0.19.0 --no-deps
```

---

## Install Python Dependencies

```bash
python3 -m pip install \
    transformers==4.45.2 \
    accelerate \
    pillow \
    sentencepiece \
    protobuf \
    safetensors \
    einops

python3 -m pip install numba==0.60.0
```

Verify Transformers:

```bash
python3 -c "
import transformers
print(transformers.__version__)
"
```

---

## Optional Processing Script Patch

```bash
# sed -i 's/super().__call__(images, return_tensors="pt")/super().__call__(images=images, return_tensors="pt")/' \
# /home/ubuntu/Desktop/plamo_21_2b_vl/processing_plamo2_vl.py

# rm -rf ~/.cache/huggingface/modules/transformers_modules/plamo_21_2b_vl
```

---

## Configure the CUDA Environment

```bash
export CUDA_HOME=/usr/local/cuda
export PATH=/usr/local/cuda/bin:$PATH
export MAX_JOBS=4
```

---

## Install causal-conv1d

```bash
python3 -m pip install \
    causal-conv1d==1.6.0 \
    --no-build-isolation \
    --no-cache-dir \
    -v
```

Verify the installation:

```bash
python3 -c "
import causal_conv1d
print('causal_conv1d OK')
"
```

---

## Clean Previous Mamba Installations (Optional)

```bash
# python3 -m pip uninstall -y mamba-ssm triton

# rm -f ~/.local/lib/python3.10/site-packages/selective_scan_cuda*.so
# rm -rf ~/.local/lib/python3.10/site-packages/mamba_ssm
# rm -rf ~/.local/lib/python3.10/site-packages/mamba_ssm-*.dist-info
```

---

## Configure the Build Environment

```bash
export CUDA_HOME=/usr/local/cuda
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
export TORCH_CUDA_ARCH_LIST="8.7"
export MAX_JOBS=4
export MAMBA_FORCE_BUILD=TRUE
```

---

## Install mamba-ssm

```bash
python3 -m pip install \
    mamba-ssm==2.3.0 \
    --no-build-isolation \
    --no-cache-dir \
    --no-binary=mamba-ssm \
    -v
```

---

## Verify the CUDA Extension

Locate the compiled extension:

```bash
find ~/.local/lib/python3.10/site-packages \
    -name "selective_scan_cuda*"
```

Inspect the compiled binary:

```bash
file ~/.local/lib/python3.10/site-packages/selective_scan_cuda*.so
```

---

## Optional Manual Modification

```bash
# nano /home/ubuntu/.local/lib/python3.10/site-packages/mamba_ssm/distributed/distributed_utils.py
```

---

## Final Verification

Verify each installed component:

```bash
python3 -c "
import torch
print(torch.__version__)
print(torch.cuda.is_available())
print(torch.cuda.get_device_name(0))
"
```

```bash
python3 -c "
import transformers
print(transformers.__version__)
"
```

```bash
python3 -c "
import causal_conv1d
print('causal_conv1d OK')
"
```

```bash
python3 -c "
import mamba_ssm
print('mamba_ssm OK')
"
```
