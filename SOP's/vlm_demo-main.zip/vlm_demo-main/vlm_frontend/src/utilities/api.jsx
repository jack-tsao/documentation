const API_BASE_URL = "http://localhost:8000/vlm"

export const API_ROUTES = {
    MODEL_STATUS: `${API_BASE_URL}/model-status/`, //model status api
    ANALYZE: `${API_BASE_URL}/analyze/`,   // image + input 
    RESULT: (taskId) => `${API_BASE_URL}/result/${taskId}`, //AI result
    LOAD: `${API_BASE_URL}/load/`,         // trigger load
    UNLOAD: `${API_BASE_URL}/unload/`,     // trigger unload
    TRANSLATE: `${API_BASE_URL}/translate/`, // trigger translation
};

export default API_ROUTES;