// FLAG FOR RYAN REVIEW: Hi Ryan I implemented the changes I proposed for the model loading and memory purging vram cleanup, the main changes can be found by keyword seacrhing REVIEWFLAG1, REVIEWFLAG2, etc.

import React, { useState, useEffect, useRef, memo } from "react";
import svgPaths from "./imports/Desktop4/svg-x0zxw91gog";
import { API_ROUTES } from "./utilities/api";
import LandingPage from "./components/LandingPage";
import SoftAurora from "./components/SoftAurora";
import { useTranslation } from 'react-i18next';
import './i18n';

const translateTextOnTheFly = async (text, sourceLang, targetLang) => {
  try {
    const formData = new URLSearchParams();
    formData.append("text", text);
    formData.append("source_lang", sourceLang);
    formData.append("target_lang", targetLang);
    const response = await fetch(API_ROUTES.TRANSLATE, {
      method: "POST",
      body: formData,
    });
    const data = await response.json();
    return data.translation || text;
  } catch (err) {
    console.error("Translation failed:", err);
    return text;
  }
};

// Theme Toggle Button
const ThemeToggle = memo(function ThemeToggle({ isDarkMode, onToggle }) {
  const { t } = useTranslation();
  return (
    <button
      onClick={onToggle}
      className="group relative flex items-center justify-center w-16 h-16 bg-white hover:bg-slate-100 rounded-full shadow-lg transition-all duration-200 cursor-pointer"
      aria-label="Toggle Theme"
      title={t('toggleDarkMode')}
    >
      {isDarkMode ? (
        // Moon icon for dark mode
        <svg className="w-8 h-8" fill="#000000" viewBox="0 0 20 20">
          <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"></path>
        </svg>
      ) : (
        // Sun icon for light mode
        <svg className="w-8 h-8" fill="#000000" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4.22 4.22a1 1 0 011.415 0l.708.708a1 1 0 01-1.414 1.414l-.708-.708a1 1 0 010-1.414zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM14.95 15.657a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM10 18a1 1 0 01-1-1v-1a1 1 0 112 0v1a1 1 0 01-1 1zm-4.22-4.22a1 1 0 01-1.415 0l-.708-.708a1 1 0 011.414-1.414l.708.708a1 1 0 010 1.414zM2 10a1 1 0 011-1h1a1 1 0 110 2H3a1 1 0 01-1-1zm3.343-4.95a1 1 0 011.414 1.414l-.707.707a1 1 0 01-1.414-1.414l.707-.707zM10 6a4 4 0 100 8 4 4 0 000-8z" clipRule="evenodd"></path>
        </svg>
      )}
    </button>
  );
});

// top right langauge button
const LanguageSwitcher = memo(function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const isEnglish = i18n.language.startsWith('en');

  return (
    <button
      onClick={() => i18n.changeLanguage(isEnglish ? 'ja' : 'en')}
      style={{ position: 'fixed', top: '24px', right: '24px', zIndex: 9999 }}
      className="px-4 py-2 rounded-full text-xs font-bold shadow-lg bg-[#004280] hover:bg-[#003366] transition-all duration-200 text-white"
    >
      {isEnglish ? '日本語' : 'EN'}
    </button>
  );
});

// Top-left status badge indicating active stream vs offline standby state
const OnlineIndicator = memo(function OnlineIndicator({ hasVideo }) {
  const { t } = useTranslation();
  
  return (
    <div className={`flex gap-2.5 items-center px-4 py-2 rounded-full shadow-lg ${hasVideo ? "bg-emerald-500 animate-pulse" : "bg-red-600"}`}>
      <div className="relative w-2 h-2">
        <div className={`absolute inset-0 rounded-full bg-white ${hasVideo ? "animate-pulse" : ""}`} />
      </div>
      <span className="font-['Outfit',sans-serif] font-semibold text-xs text-white tracking-widest uppercase">
        {hasVideo ? t('droneFeed') : t('standby')}
      </span>
    </div>
  );
});

// File input button for uploading local video streams
// Left control: Cancel Video Button (Camera with a slash)
const CancelVideoButton = memo(function CancelVideoButton({ onClick, disabled }) {
  const { t } = useTranslation();
  
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative flex items-center justify-center w-16 h-16 bg-white hover:bg-slate-100 rounded-full shadow-lg transition-all duration-200 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
      aria-label={t('cancelVideo')}
      title={t('cancelVideoFeed')}
    >
      <svg className="w-7 h-7 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 3l18 18" className="text-red-600 stroke-red-600" />
      </svg>
    </button>
  );
});

// Middle control: Upload Button (Cloud with upward arrow)
const CloudUploadButton = memo(function CloudUploadButton({ onFileChange }) {
  const { t } = useTranslation();
  return (
    <div className="relative">
      <input
        type="file"
        accept="video/*,image/*"
        onChange={(e) => {
          if (e.target.files?.[0]) {
            onFileChange(e.target.files[0]);
          }
        }}
        className="hidden"
        id="video-upload-input"
      />
      <label
        htmlFor="video-upload-input"
        className="group relative flex items-center justify-center w-20 h-20 bg-white rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 cursor-pointer"
        aria-label={t('uploadMedia')}
        title={t('uploadMedia')}
      >
        <svg className="w-9 h-9 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" />
        </svg>
      </label>
    </div>
  );
});

// Right control: Clear Chat Button (Chat bubble with a slash)
const ClearChatButton = memo(function ClearChatButton({ onClick, disabled }) {
  const { t } = useTranslation();
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative flex items-center justify-center w-16 h-16 bg-white hover:bg-slate-100 rounded-full shadow-lg transition-all duration-200 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
      aria-label={t('clearChat')}
      title={t('clearChatLogs')}
    >
      <svg className="w-7 h-7 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 3l18 18" className="text-red-600 stroke-red-600" />
      </svg>
    </button>
  );
});

// Middle control: Play/Pause Button
const PlayPauseButton = memo(function PlayPauseButton({ isPlaying, onClick, disabled }) {
  const { t } = useTranslation();
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative flex items-center justify-center w-20 h-20 bg-white rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
      aria-label={isPlaying ? t('pause') : t('play')}
      title={isPlaying ? t('pause') : t('play')}
    >
      {isPlaying ? (
        <svg className="w-9 h-9 text-slate-800" fill="currentColor" viewBox="0 0 24 24">
          <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
        </svg>
      ) : (
        <svg className="w-9 h-9 pl-1 text-slate-800" fill="currentColor" viewBox="0 0 24 24">
          <path d="M8 5v14l11-7z"/>
        </svg>
      )}
    </button>
  );
});

// Left control: Skip Backward 3s
const SkipBackwardButton = memo(function SkipBackwardButton({ onClick, disabled }) {
  const { t } = useTranslation();
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative flex items-center justify-center w-16 h-16 bg-white hover:bg-slate-100 rounded-full shadow-lg transition-all duration-200 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
      aria-label={t('skipBackward')}
      title={t('skipBackward')}
    >
      <svg className="w-7 h-7 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.333 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z" />
      </svg>
    </button>
  );
});

// Right control: Skip Forward 3s
const SkipForwardButton = memo(function SkipForwardButton({ onClick, disabled }) {
  const { t } = useTranslation();
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative flex items-center justify-center w-16 h-16 bg-white hover:bg-slate-100 rounded-full shadow-lg transition-all duration-200 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
      aria-label={t('skipForward')}
      title={t('skipForward')}
    >
      <svg className="w-7 h-7 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.933 12.8a1 1 0 000-1.6l-5.333-4A1 1 0 005 8v8a1 1 0 001.6.8l5.333-4zM19.933 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.334-4z" />
      </svg>
    </button>
  );
});

// Media player component managing video playback and bounding box overlays
function CameraFeed({
  videoSrc,
  hasVideo,
  onFileChange,
  isProcessing,
  detections,
  onCancelVideo,
  onClearChat,
  chatEmpty,
  videoTime, // Keep this prop if we want, or remove it. Let's remove it and handle locally.
  onTimeUpdate // Remove
}) {
  const { t } = useTranslation();
  const videoRef = useRef(null);
  const [localVideoTime, setLocalVideoTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  const skipTime = (amount) => {
    if (videoRef.current) {
      videoRef.current.currentTime += amount;
    }
  };

  // Synchronize internal state with video playback timeline
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setLocalVideoTime(videoRef.current.currentTime);
    }
  };

  // Find bounding box detections that match the current video playback timestamp
  const activeFrame = detections.find(
    (d) => Math.abs(d.time - localVideoTime) <= 1.0
  );

  return (

    <div className="relative w-full max-w-[920px] h-[540px] bg-[#020617] rounded-2xl overflow-hidden shadow-2xl border-2 dark:border-slate-800 border-slate-300/80">
      
      {/* Top-left status badge */}
      <div className="absolute top-7 left-7 z-10">
        <OnlineIndicator hasVideo={hasVideo} />
      </div>

      {hasVideo && videoSrc ? (
        /* Video Player Element */
        <video
          ref={videoRef}
          src={videoSrc}
          onTimeUpdate={handleTimeUpdate}
          autoPlay
          loop
          muted
          playsInline
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          className="w-full h-full object-cover animate-in fade-in duration-500"
        />
      ) : (
        /* Standby state when no video file has been uploaded */
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 p-8 border border-slate-900">
          <div className="w-24 h-24 rounded-full dark:bg-slate-900 bg-white/90 border-2 border-red-500 flex items-center justify-center mb-6 shadow-[0_0_20px_rgba(239,68,68,0.4)] animate-pulse">
            <svg className="w-12 h-12 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z" />
            </svg>
          </div>
          <p className="text-red-500 text-base max-w-md text-center font-['Outfit',sans-serif] font-semibold tracking-wide animate-pulse px-4">
            {t('uploadPrompt')}
          </p>
        </div>
      )}

      {/* Decorative scanline overlay */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[length:100%_4px] opacity-25" />
      
      {/* HUD alignment grid */}
      <div className="absolute inset-0 pointer-events-none border border-emerald-500/10 grid grid-cols-4 grid-rows-4">
        {[...Array(16)].map((_, i) => (
          <div key={i} className="border border-emerald-500/5" />
        ))}
      </div>

      {/* Synchronized bounding box targets overlay */}
      {hasVideo && activeFrame && activeFrame.boxes.map((box, index) => (
        <div
          key={index}
          className="absolute border-2 border-emerald-400 bg-emerald-500/5 font-mono text-[10px] text-emerald-300 font-bold px-1.5 py-0.5 transition-all duration-200 pointer-events-none rounded shadow-[0_0_12px_rgba(16,185,129,0.3)]"
          style={{
            left: `${box.x}%`,
            top: `${box.y}%`,
            width: `${box.w}%`,
            height: `${box.h}%`,
          }}
        >
          {/* Label displaying category name and model confidence level */}
          <div className="absolute -top-6 left-0 bg-slate-950/80 text-emerald-400 border border-emerald-500/20 text-[9px] px-1.5 py-0.5 rounded shadow">
            {box.label} ({Math.round(box.confidence * 100)}%)
          </div>
          {/* Corner highlights to enhance visual alignment UI */}
          <div className="absolute top-0 left-0 w-1.5 h-1.5 border-t-2 border-l-2 border-white" />
          <div className="absolute top-0 right-0 w-1.5 h-1.5 border-t-2 border-r-2 border-white" />
          <div className="absolute bottom-0 left-0 w-1.5 h-1.5 border-b-2 border-l-2 border-white" />
          <div className="absolute bottom-0 right-0 w-1.5 h-1.5 border-b-2 border-r-2 border-white" />
        </div>
      ))}

      {/* Visual loader visible when API is running inference */}
      {isProcessing && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-300">
          <div className="flex flex-col items-center gap-5 p-7 dark:bg-slate-900 bg-white/90 border border-slate-700/80 rounded-2xl max-w-sm shadow-2xl text-center">
            <div className="relative w-16 h-16">
              <div className="absolute inset-0 rounded-full border-4 dark:border-slate-800 border-slate-300" />
              <div className="absolute inset-0 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin" />
            </div>
            <div>
              <div className="text-lg font-['Cormorant_Garamond',serif] font-bold dark:text-white text-slate-900 mb-1">VLM Video Processing</div>
              <div className="text-xs text-slate-400 font-mono tracking-widest animate-pulse uppercase">Analyzing frame-by-frame details...</div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive control buttons dock overlay (Playback) */}
      <div className="absolute bottom-7 left-1/2 -translate-x-1/2 flex items-center gap-6 bg-slate-950/80 p-3 rounded-full border dark:border-slate-800 border-slate-300/55 shadow-2xl backdrop-blur-md">
        <SkipBackwardButton onClick={() => skipTime(-3)} disabled={!hasVideo} />
        <PlayPauseButton isPlaying={isPlaying} onClick={togglePlayPause} disabled={!hasVideo} />
        <SkipForwardButton onClick={() => skipTime(3)} disabled={!hasVideo} />
      </div>
    </div>
  );
}


// Arrow submit button to post data to Django backend
const SendButton = memo(function SendButton({ onClick, disabled }) {
  const { t } = useTranslation();
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative w-16 h-16 hover:scale-110 transition-all duration-300 ease-out disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:scale-100"
      aria-label={t('send')}
    >
      <div className="absolute inset-0 dark:bg-slate-900 bg-white/90 rounded-full shadow-xl group-hover:shadow-2xl group-hover:bg-slate-800 transition-all duration-300" />
      <svg className="absolute inset-0 m-auto w-7 h-7 dark:text-white text-slate-900 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" fill="none" viewBox="0 0 24 24">
        <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 8L11 13" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
      </svg>
    </button>
  );
});

// Icon for human user messages
const UserAvatar = memo(function UserAvatar() {
  return (
    <div className="relative w-12 h-12 shrink-0 bg-slate-800 rounded-full shadow-md flex items-center justify-center">
      <svg className="w-6 h-6 dark:text-white text-slate-900" fill="none" viewBox="0 0 24 24">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
      </svg>
    </div>
  );
});

// Icon for assistant VLM model messages
const AssistantAvatar = memo(function AssistantAvatar() {
  return (
    <div className="relative w-12 h-12 shrink-0 bg-emerald-700 rounded-full shadow-md flex items-center justify-center">
      <span className="dark:text-white text-slate-900 font-bold font-mono text-sm">VLM</span>
    </div>
  );
});

// Single bubble component in the conversation log
const ChatMessage = memo(function ChatMessage({ message }) {
  const { i18n } = useTranslation();
  const isUser = message.type === "user";

  return (
    <div className={`flex gap-4 items-start w-full max-w-4xl animate-in slide-in-from-bottom-3 fade-in duration-700 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && <AssistantAvatar />}
      <div className={`max-w-2xl ${isUser ? "ml-auto" : ""}`}>
        <div className={`${isUser ? "bg-[#004280]" : "dark:bg-slate-900 bg-white/90 border dark:border-slate-800 border-slate-300"} px-7 py-5 rounded-3xl shadow-lg hover:shadow-xl transition-shadow duration-300`}>
          <p className="font-['Outfit',sans-serif] font-normal text-[16px] leading-relaxed dark:text-white text-slate-900 whitespace-pre-wrap">
            {typeof message.content === 'string' ? message.content : message.content[i18n.language.startsWith('en') ? 'en' : 'ja']}
          </p>
          {message.imageUrl && (
            <div className="mt-4 rounded-2xl overflow-hidden border dark:border-slate-800 border-slate-300/80 bg-slate-950">
              <img
                src={message.imageUrl}
                alt="VLM Detection Keyframe"
                className="w-full h-auto object-contain max-h-[360px] block"
              />
            </div>
          )}
        </div>
      </div>
      {isUser && <UserAvatar />}
    </div>
  );
});


// Left sidebar panel tracking history of analyzed runs
function Navbar({ isOpen, onToggle, chatHistory, onChatSelect }) {
  const [searchQuery, setSearchQuery] = useState("");

  const { t } = useTranslation();

  const filteredHistory = chatHistory.filter(chat => 
    chat.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
   
    <>
      <div className={`fixed left-0 top-0 h-screen bg-[#004280] transition-all duration-300 ease-out z-50 ${isOpen ? "w-[320px]" : "w-0"} overflow-hidden shadow-2xl`}>
        <div className="w-[320px] h-full flex flex-col">
          <div className="h-20 flex items-center justify-between px-7 border-b border-white/10">
            <span className="font-['Cormorant_Garamond',serif] font-bold text-white text-base tracking-wide">{t('sideBarHeader')}</span>
            <button
              onClick={onToggle}
              className="w-10 h-10 hover:bg-white/10 rounded-lg transition-all duration-200 flex items-center justify-center"
              aria-label="Close menu"
            >
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
              </svg>
            </button>
          </div>

          <div className="flex flex-col flex-1 overflow-y-auto py-6">
            {/* Search Input Box */}
            <div className="flex items-center gap-3 mx-6 mb-8 px-5 py-4 bg-white/10 rounded-xl border border-white/20 focus-within:bg-white/15 transition-all duration-200">
              <svg className="w-5 h-5 text-white/70" fill="none" viewBox="0 0 18 18">
                <path d={svgPaths.p16b4a380} fill="currentColor" />
              </svg>
              <input
                type="text"
                placeholder={t('search')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent font-['Outfit',sans-serif] font-normal text-[15px] text-white placeholder:text-white/50 outline-none flex-1"
              />
            </div>

            {/* Sidebar Runs List */}
            <div className="flex flex-col gap-2 mx-4">
              <p className="font-['Outfit',sans-serif] font-bold text-sm text-white/60 uppercase tracking-wider px-3 mb-2">{t('history')}</p>
              {filteredHistory.length > 0 ? (
                filteredHistory.map((chat) => (
                  <button
                    key={chat.id}
                    onClick={() => onChatSelect(chat.id)}
                    className="flex flex-col text-left px-5 py-4 rounded-xl hover:bg-white/10 transition-colors duration-200 group border border-transparent hover:border-white/10"
                  >
                    <p className="font-['Outfit',sans-serif] font-medium text-[15px] text-white/90 group-hover:text-white truncate">
                      {chat.title}
                    </p>
                    <p className="text-[10px] text-white/40 mt-0.5">
                      {chat.date} • {chat.duration}
                    </p>
                  </button>
                ))
              ) : (
                <p className="text-sm text-white/40 px-6 italic mt-2">{t('noHistory')}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Toggle Sidebar Menu Button */}
      {!isOpen && (
        <div className="fixed left-7 top-7 z-40">
          <button
            onClick={onToggle}
            className="w-14 h-14 bg-[#004280] hover:bg-[#003366] rounded-xl flex items-center justify-center shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-110"
            aria-label="Open menu"
          >
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" stroke="currentColor" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      )}
    </>
  );
}

// REVIEWFLAG6: This is the visual VLM Control Panel and full-screen loader screen.
// We designed these in a solid dark slate style (avoiding glassmorphism as requested)
// to integrate smoothly with the dashboard layout.
function VlmControlPanel({
  status,
  progress,
  error,
  device,
  modelName,
  onLoad,
  onUnload
}) {
  const { t } = useTranslation();
  return (
    <div className="w-full max-w-4xl dark:bg-slate-900 bg-white/90 border dark:border-slate-800 border-slate-300 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5 transition-all duration-300">
      <div className="flex flex-col gap-1.5 flex-1">
        <div className="flex items-center gap-3">
          <span className="font-['Cormorant_Garamond',serif] font-bold text-sm text-slate-400 tracking-wider uppercase">
            {t('modelName')}: {modelName}
          </span>
          {status === "idle" && (
            <span className="px-3 py-1 text-xs rounded-full font-semibold font-mono bg-slate-800 text-slate-400 border border-slate-700">
              {t('modelOffline')}
            </span>
          )}
          {status === "loading" && (
            <span className="px-3 py-1 text-xs rounded-full font-semibold font-mono bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse">
              {t('modelLoading')} ({progress}%)
            </span>
          )}
          {status === "ready" && (
            <span className="px-3 py-1 text-xs rounded-full font-semibold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.1)]">
              {t('modelOnline')} ({device})
            </span>
          )}
          {status === "error" && (
            <span className="px-3 py-1 text-xs rounded-full font-semibold font-mono bg-rose-500/10 text-rose-400 border border-rose-500/20">
              {t('modelError')}
            </span>
          )}
        </div>
        
        {status === "loading" && (
          <div className="mt-2.5 w-full bg-slate-800 rounded-full h-3.5 overflow-hidden border border-slate-700">
            <div
              className="bg-amber-500 h-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
        
        {status === "ready" && (
          <p className="text-xs text-emerald-400/80 font-mono mt-1">
            {t('modelReady')}
          </p>
        )}
        
        {status === "idle" && (
          <p className="text-xs text-slate-500 mt-1">
            {t('initModel')}
          </p>
        )}
        
        {status === "error" && (
          <p className="text-xs text-rose-400 font-mono mt-1 whitespace-pre-wrap max-w-2xl bg-rose-950/40 p-2.5 rounded-lg border border-rose-900/30">
            {error || t('initError')}
          </p>
        )}
      </div>

      <div className="flex items-center shrink-0">
        {status === "idle" && (
          <button
            onClick={onLoad}
            className="w-full md:w-auto px-6 py-3 rounded-2xl bg-[#004280] hover:bg-[#003366] text-white font-semibold font-['Cormorant_Garamond',serif] text-[14px] shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
          >
            {t('loadModel')}
          </button>
        )}
        {status === "loading" && (
          <button
            disabled
            className="w-full md:w-auto px-6 py-3 rounded-2xl bg-slate-800 text-slate-500 font-semibold font-['Outfit',sans-serif] text-[14px] border border-slate-700 cursor-not-allowed opacity-55"
          >
            {t('loading')}
          </button>
        )}
        {status === "ready" && (
          <button
            onClick={onUnload}
            className="w-full md:w-auto px-6 py-3 rounded-2xl dark:bg-rose-950/80 bg-rose-100 dark:hover:bg-rose-900 hover:bg-rose-200 dark:text-rose-200 text-rose-900 font-semibold font-['Outfit',sans-serif] text-[14px] border dark:border-rose-800/40 border-rose-300 shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
          >
            {t('unloadModel')}
          </button>
        )}
        {status === "error" && (
          <button
            onClick={onLoad}
            className="w-full md:w-auto px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-semibold font-['Outfit',sans-serif] text-[14px] shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
          >
            {t('retryLoading')}
          </button>
        )}
      </div>
    </div>
  );
}

// Helper to extract a frame from a HTML5 video element at its current time
const captureVideoFrame = (video) => {
  return new Promise((resolve) => {
    try {
      const canvas = document.createElement("canvas");
      const MAX_WIDTH = 1280;
      const MAX_HEIGHT = 720;
      let width = video.videoWidth || 640;
      let height = video.videoHeight || 480;

      if (width > MAX_WIDTH) {
        height = Math.round((height * MAX_WIDTH) / width);
        width = MAX_WIDTH;
      }
      if (height > MAX_HEIGHT) {
        width = Math.round((width * MAX_HEIGHT) / height);
        height = MAX_HEIGHT;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(video, 0, 0, width, height);
      canvas.toBlob(
        (blob) => {
          resolve(blob);
        },
        "image/jpeg",
        0.85
      );
    } catch (e) {
      console.error("Error capturing video frame:", e);
      resolve(null);
    }
  });
};

// Core App dashboard component managing React state and API integrations
export default function App() {
  const { t, i18n } = useTranslation();
  const [showLandingPage, setShowLandingPage] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Apply Tailwind dark mode class to root HTML
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);
  const [videoSrc, setVideoSrc] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [inputValue, setInputValue] = useState("");
  const [messages, setMessages] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [navbarOpen, setNavbarOpen] = useState(false);
  const [detections, setDetections] = useState([]);
  const [chatHistory, setChatHistory] = useState([]);
  const [validationError, setValidationError] = useState(null);
  const isSendingRef = useRef(false);
  
  // REVIEWFLAG5: These states and the useEffect below handle the initial first-time visit check
  // and polling. If it is a first visit (model is idle), we automatically trigger the loading progress
  // and open the full-screen loading screen. If the user refreshes, and the model is already ready,
  // we bypass the loading screen completely and show the app instantly.
  const [modelStatus, setModelStatus] = useState("idle"); // idle, loading, ready, error
  const [modelProgress, setModelProgress] = useState(0);
  const [modelError, setModelError] = useState(null);
  const [modelDevice, setModelDevice] = useState("cpu");
  const [modelName, setModelName] = useState("PLaMo 2.1-2B-VL");

  const [isInitialStatusChecked, setIsInitialStatusChecked] = useState(false);
  const [showFullScreenLoader, setShowFullScreenLoader] = useState(false);

  const triggerModelLoad = async () => {
    setModelStatus("loading");
    setModelProgress(0);
    setModelError(null);
    try {
      const response = await fetch(API_ROUTES.LOAD, { method: "POST" });
      if (!response.ok) {
        throw new Error('loadTriggerFailed');
      }
    } catch (error) {
      console.error(t('loadError'), error);
      setModelStatus("error");
      setModelError(error.message);
    }
  };

  const triggerModelUnload = async () => {
    try {
      const response = await fetch(API_ROUTES.UNLOAD, { method: "POST" });
      if (!response.ok) {
        throw new Error('modelUnloadTriggerFailed');
      }
      setModelStatus("idle");
      setModelProgress(0);
      setModelError(null);
      setShowFullScreenLoader(false);
    } catch (error) {
      console.error(t('unloadError'), error);
      setModelStatus("error");
      setModelError(error.message);
    }
  };

  // Poll model status when in "loading" state
  useEffect(() => {
    let intervalId = null;

    const checkStatus = async () => {
      try {
        const response = await fetch(API_ROUTES.MODEL_STATUS);
        if (!response.ok) {
          throw new Error('modelStatusCheckFailed');
        }
        const data = await response.json();
        setModelStatus(data.status);
        setModelProgress(data.progress);
        setModelDevice(data.device || "cpu");
        setModelName(data.model_name || "PLaMo 2.1-2B-VL");
        if (data.error) {
          setModelError(data.error);
        } else {
          setModelError(null);
        }

        // Logic for first time visitor automatic load trigger & full screen control
        if (!isInitialStatusChecked) {
          if (data.status === "idle") {
            // Trigger loading automatically on the first visit
            triggerModelLoad();
            setShowFullScreenLoader(true);
          } else if (data.status === "loading") {
            setShowFullScreenLoader(true);
          } else {
            setShowFullScreenLoader(false);
          }
          setIsInitialStatusChecked(true);
        } else {
          // Normal flow: if model becomes ready, close the loader
          if (data.status === "ready" || data.status === "error" || data.status === "idle") {
            if (data.status === "ready") {
              setShowFullScreenLoader(false);
            }
            if (intervalId) clearInterval(intervalId);
          }
        }
      } catch (error) {
        console.error(t('pollingError'), error);
        if (!isInitialStatusChecked) {
          setIsInitialStatusChecked(true);
        }
      }
    };

    // Run first check immediately on mount to establish state
    checkStatus();

    if (modelStatus === "loading") {
      intervalId = setInterval(checkStatus, 1000);
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [modelStatus, isInitialStatusChecked]);

  // Clear validation warnings immediately when prompt text changes
  useEffect(() => {
    if (inputValue.trim()) {
      setValidationError(null);
    }
  }, [inputValue]);

  // Load selected local file visually into browser memory blob
  const handleFileChange = (file) => {
    setUploadedFile(file);
    const objectUrl = URL.createObjectURL(file);
    setVideoSrc(objectUrl);
    setDetections([]);
    setValidationError(null);
  };

  // Capture mockup fallback processing
  const handleCaptureBackup = () => {
    if (!uploadedFile) {
      setValidationError('infWithoutVideoError');
      return;
    }

    const timeMark = new Date();
    const userMsg = {
      id: `user-${Date.now()}`,
      type: "user",
      content: {
        en: "Captured backup frame analysis",
        ja: "バックアップフレームのキャプチャ分析"
      },
      timestamp: timeMark,
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsProcessing(true);

    setTimeout(() => {
      const assistantMsg = {
        id: `vlm-${Date.now()}`,
        type: "assistant",
        content: "Frame Capture Diagnostic (Backup Workflow)\n\nCamera frame recorded successfully.\n- Average brightness index: 76%\n- Structural targets: 3 identified\n- Edge-detection algorithm: 94.2% confidence output.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setIsProcessing(false);
    }, 1000);
  };

  // Handle post operations to the Django REST endpoint
  const handleSend = async () => {
    if (isSendingRef.current) return;

    // Validate inputs
    if (!uploadedFile) {
      setValidationError('infWithoutVideoError');
      return;
    }

    if (!inputValue.trim()) {
      setValidationError('infWithoutPromptError');
      return;
    }

    // REVIEWFLAG7: This is a validation guard. We prevent the user from sending prompts
    // if the VLM model is offline, prompting them to load the model first.
    if (modelStatus !== "ready") {
      setValidationError('modelNotOnlineError');
      return;
    }

    setValidationError(null);
    isSendingRef.current = true;
    setInputValue("");
    setIsProcessing(true);

    const currentLang = i18n.language.startsWith('en') ? 'en' : 'ja';
    const userMessage = {
      id: `msg-${Date.now()}`,
      type: "user",
      content: {
        en: currentLang === 'en' ? inputValue : await translateTextOnTheFly(inputValue, 'ja', 'en'),
        ja: currentLang === 'ja' ? inputValue : await translateTextOnTheFly(inputValue, 'en', 'ja')
      },
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);

    try {
      const tStartFrontendProcess = performance.now();
      let fileToSend = uploadedFile;
      let filenameToSend = uploadedFile.name;

      const isVideo = uploadedFile.type.startsWith("video/") || /\.(mp4|avi|mov|mkv|webm)$/i.test(uploadedFile.name);
      if (isVideo) {
        const videoElement = document.querySelector("video");
        if (videoElement) {
          const blob = await captureVideoFrame(videoElement);
          if (blob) {
            fileToSend = new File([blob], "extracted_frame.jpg", { type: "image/jpeg" });
            filenameToSend = "extracted_frame.jpg";
          }
        }
      }

      // Package parameters into multipart form payload
      const formData = new FormData();
      formData.append("video", fileToSend, filenameToSend);
      
      // Optimization: Send the already-translated English string to the backend to bypass backend translation
      const promptText = typeof userMessage.content === 'string' ? userMessage.content : userMessage.content.en;
      formData.append("prompt", promptText);
      
      // Pass the captured video playback time to the backend for frame extraction
      const videoElementToTime = document.querySelector("video");
      const currentVideoTime = videoElementToTime ? videoElementToTime.currentTime : 0;
      formData.append("timestamp", currentVideoTime.toString());

      const tEndFrontendProcess = performance.now();
      console.log(`[PROFILE] Frontend Keyframe Processing Time: ${((tEndFrontendProcess - tStartFrontendProcess) / 1000).toFixed(3)}s`);

      // Perform request to Django API (Port 8000)
      const tStartFrontendSend = performance.now();
      const response = await fetch(API_ROUTES.ANALYZE, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      const tEndFrontendSend = performance.now();
      console.log(`[PROFILE] Frontend Send to Django Time (Initial POST): ${((tEndFrontendSend - tStartFrontendSend) / 1000).toFixed(3)}s`);
      
      let finalData = data;
      const taskId = data.taskId || data.task_id;

      if (taskId) {
        // If an async taskId is returned, poll for the final result
        finalData = await new Promise((resolve, reject) => {
          const pollInterval = setInterval(async () => {
            try {
              const res = await fetch(API_ROUTES.RESULT(taskId));
              if (!res.ok) {
                throw new Error(`Result fetch returned status ${res.status}`);
              }
              const taskResult = await res.json();
              if (taskResult.status === "completed" || taskResult.status === "success" || taskResult.vlm_response) {
                clearInterval(pollInterval);
                resolve(taskResult);
              } else if (taskResult.status === "failed" || taskResult.status === "error") {
                clearInterval(pollInterval);
                reject(new Error(taskResult.error || "Async task execution failed on   backend"));
              }
            } catch (err) {
              clearInterval(pollInterval);
              reject(err);
            }
          }, 1500);
        });
      }

      // Synchronize keyframe bounding box targets
      if (finalData.detections) {
        setDetections(finalData.detections);
      }

      // Add assistant response to messages log
      let finalEn = finalData.vlm_response_en;
      let finalJa = finalData.vlm_response_ja || "翻訳中... (Translating...)";
      
      let timeStr = "";
      if (finalData.timings) {
        console.table(finalData.timings);
        if (finalData.timings.total_backend_time) {
          timeStr = `\n\n*(Total Backend Time: ${finalData.timings.total_backend_time.toFixed(2)}s)*`;
          finalEn += timeStr;
          if (finalData.vlm_response_ja) {
            finalJa += timeStr;
          }
        }
      }

      const assistantMsgId = `msg-${Date.now()}-ai`;
      const assistantMessage = {
        id: assistantMsgId,
        type: "assistant",
        content: {
          en: finalEn, //  Reads dual-strings from backend
          ja: finalJa
        },
        timestamp: new Date(),
        imageUrl: finalData.image_url || finalData.imageUrl,
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Save to chat run records sidebar
      const newSession = {
        id: `session-${Date.now()}`,
        title: finalData.scenario || `VLM Inference: ${(typeof userMessage.content === 'string' ? userMessage.content : userMessage.content.en).slice(0, 20)}...`,
        timestamp: new Date(),
        messages: [userMessage, assistantMessage],
        videoUrl: videoSrc || "",
        detections: finalData.detections || [],
      };
      setChatHistory((prev) => [newSession, ...prev]);

      // Asynchronously translate if Japanese response is missing
      if (!finalData.vlm_response_ja) {
        translateTextOnTheFly(finalData.vlm_response_en, 'en', 'ja').then((translatedJa) => {
          const newJaContent = translatedJa + timeStr;
          
          setMessages((prevMsgs) => prevMsgs.map(msg => 
            msg.id === assistantMsgId ? { ...msg, content: { ...msg.content, ja: newJaContent } } : msg
          ));
          
          setChatHistory((prevHistory) => prevHistory.map(session => {
            if (session.messages.some(m => m.id === assistantMsgId)) {
              const updatedMsgs = session.messages.map(m => 
                m.id === assistantMsgId ? { ...m, content: { ...m.content, ja: newJaContent } } : m
              );
              return { ...session, messages: updatedMsgs };
            }
            return session;
          }));
        });
      }


    } catch (error) {
      console.error("VLM Inference API failed:", error);
      
      const failedMsg = {
        id: `msg-${Date.now()}-failed`,
        type: "assistant",
        content: `API Request Failed: ${error.message || t('networkError')}`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, failedMsg]);


    } finally {
      setIsProcessing(false);
      isSendingRef.current = false;
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Restore state parameters when selecting past sessions from sidebar history
  const handleChatSelect = (chatId) => {
    const selectedSession = chatHistory.find(chat => chat.id === chatId);
    if (selectedSession) {
      setVideoSrc(selectedSession.videoUrl);
      setDetections(selectedSession.detections);
      setMessages(selectedSession.messages);
      setUploadedFile(new File([], "restored_session.mp4"));
      setValidationError(null);
    }
    setNavbarOpen(false);
  };

  const handleCancelVideo = () => {
    setVideoSrc(null);
    setUploadedFile(null);
    setDetections([]);
    setValidationError(null);
  };

  const handleClearChat = () => {
    setMessages([]);
    setValidationError(null);
  };

  const placeholder = uploadedFile
    ? t('analyzeVideo')
    : t('uploadVideo');

  if (!isInitialStatusChecked) {
    return (
      <div className="relative w-screen h-screen flex flex-col items-center justify-center bg-[#020617]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-full border-4 dark:border-slate-800 border-slate-300 border-t-[#004280] animate-spin" />
          <span className="text-sm font-semibold font-['Outfit',sans-serif] text-slate-400 tracking-wider">
            {t('connecting')}
          </span>
        </div>
      </div>
    );
  }

  if (showFullScreenLoader) {
    return (
      <div className="relative w-screen h-screen flex flex-col items-center justify-center bg-[#020617] px-6">
        <div className="w-full max-w-xl dark:bg-slate-900 bg-white/90 border dark:border-slate-800 border-slate-300 rounded-3xl p-8 shadow-2xl flex flex-col items-center gap-7 animate-in fade-in zoom-in-95 duration-500">
          <div className="relative w-20 h-20 flex items-center justify-center mb-1">
            <div className="absolute inset-0 rounded-full border-4 dark:border-slate-800 border-slate-300" />
            <div className="absolute inset-0 rounded-full border-4 border-amber-500 border-t-transparent animate-spin" />
            <span className="dark:text-white text-slate-900 font-mono font-bold text-sm">VLM</span>
          </div>

          <div className="text-center">
            <h2 className="text-2xl font-['Cormorant_Garamond',serif] font-bold dark:text-white text-slate-900 mb-2 tracking-wide uppercase">
              {t('loadingVLM')}
            </h2>
            <p className="text-sm text-slate-400 font-['Outfit',sans-serif] max-w-sm mx-auto leading-relaxed">
              {t('loadingWeights')} **{modelName}** {t('device')} **{modelDevice}**...
            </p>
          </div>

          <div className="w-full flex flex-col gap-2">
            <div className="flex justify-between items-center px-1">
              <span className="text-xs font-bold font-mono text-slate-500 uppercase tracking-wider">
                {modelProgress < 30 && t('modelProgress1')}
                {modelProgress >= 30 && modelProgress < 75 && t('modelProgress2')}
                {modelProgress >= 75 && modelProgress < 90 && t('modelProgress3')}
                {modelProgress >= 90 && modelProgress < 100 && t('modelProgress4')}
                {modelProgress === 100 && t('modelProgress5')}
              </span>
              <span className="text-sm font-bold font-mono text-amber-400">
                {modelProgress}%
              </span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-4 overflow-hidden border border-slate-700">
              <div
                className="bg-amber-500 h-full transition-all duration-300 ease-out"
                style={{ width: `${modelProgress}%` }}
              />
            </div>
          </div>

          {modelError && (
            <div className="w-full dark:bg-rose-950/40 bg-rose-100 p-4 rounded-xl border dark:border-rose-900/30 border-rose-300 text-xs dark:text-rose-300 text-rose-900 font-mono text-left overflow-y-auto max-h-36">
              {t(modelError)}
            </div>
          )}

          {modelError && (
            <button
              onClick={triggerModelLoad}
              className="px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-semibold font-['Outfit',sans-serif] text-sm transition-all duration-200"
            >
              Retry Load
            </button>
          )}
        </div>
      </div>
    );
  }

  if (showLandingPage) {
    return <LandingPage onStart={() => setShowLandingPage(false)} />;
  }

  return (
    <>
    {<LanguageSwitcher />}
      
    <div className={`relative size-full overflow-hidden ${isDarkMode ? "bg-slate-950 dark:text-white text-slate-900" : "bg-slate-50 text-slate-900"}`}>
      {/* Background SoftAurora */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <SoftAurora
          speed={0.4}
          scale={1.2}
          color1="#004280"
          color2="#e100ff"
          brightness={isDarkMode ? 0.8 : 1.0}
        />
      </div>

      <Navbar
        isOpen={navbarOpen}
        onToggle={() => setNavbarOpen(!navbarOpen)}
        chatHistory={chatHistory}
        onChatSelect={handleChatSelect}
      />

      {/* Floating Vertical Dock for Original Controls */}
      {!showLandingPage && (
        <div className="fixed left-6 top-1/2 -translate-y-1/2 flex flex-col items-center gap-6 bg-slate-950/80 p-3 rounded-full border dark:border-slate-800 border-slate-300/55 shadow-2xl backdrop-blur-md z-40">
          <ThemeToggle isDarkMode={isDarkMode} onToggle={() => setIsDarkMode(!isDarkMode)} />
          <div className="w-10 h-px bg-slate-800" />
          <CancelVideoButton onClick={handleCancelVideo} disabled={!uploadedFile} />
          <CloudUploadButton onFileChange={handleFileChange} />
          <ClearChatButton onClick={handleClearChat} disabled={messages.length === 0} />
        </div>
      )}

      <div className="relative size-full flex items-start justify-center overflow-y-auto pt-28 pb-16">
        <div className="flex flex-col gap-12 items-center w-full max-w-[1400px] px-8">
          
          <CameraFeed
            videoSrc={videoSrc}
            hasVideo={!!uploadedFile}
            onFileChange={handleFileChange}
            isProcessing={isProcessing}
            detections={detections}
            onCancelVideo={handleCancelVideo}
            onClearChat={handleClearChat}
            chatEmpty={messages.length === 0}
          />

          <VlmControlPanel
            status={modelStatus}
            progress={modelProgress}
            error={modelError}
            device={modelDevice}
            modelName={modelName}
            onLoad={triggerModelLoad}
            onUnload={triggerModelUnload}
          />

          <div className="w-full flex flex-col gap-7 items-center">
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}

            {isProcessing && (
              <div className="flex gap-4 items-start w-full max-w-4xl animate-in slide-in-from-bottom-3 fade-in duration-700">
                <AssistantAvatar />
                <div className="bg-[#004280]/10 border border-[#004280]/20 px-7 py-5 rounded-3xl">
                  <div className="flex gap-2.5">
                    <div className="w-2.5 h-2.5 bg-[#004280] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2.5 h-2.5 bg-[#004280] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2.5 h-2.5 bg-[#004280] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}

            <div className="w-full max-w-4xl mt-6">
              {/* Validation alert banner displaying text warnings */}
              {validationError && (
                <div className="mb-4 px-6 py-3 bg-red-950/80 border border-red-500/30 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-bottom-1 duration-200">
                  <svg className="w-5 h-5 text-red-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                  </svg>
                  <span className="font-mono text-sm text-red-200 font-semibold">{t(validationError)}</span>
                </div>
              )}

              <div className="flex gap-5 items-center w-full">
                <div className="flex-1">
                  <div className="bg-[#004280] rounded-3xl shadow-xl hover:shadow-2xl transition-shadow duration-300">
                    <input
                      type="text"
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder={placeholder}
                      disabled={isProcessing}
                      className="bg-transparent font-['Cormorant_Garamond',serif] font-normal text-[17px] text-white placeholder:text-white/60 w-full outline-none px-7 py-5 disabled:cursor-not-allowed"
                    />
                  </div>
                </div>
                <SendButton
                  onClick={handleSend}
                  disabled={isProcessing}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
