import React from 'react';
import { useTranslation } from 'react-i18next';

export default function LanguageSwitcher() {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'ja' : 'en';
    i18n.changeLanguage(newLang);
  };

  return (
    <button 
      onClick={toggleLanguage}
      className="absolute top-6 right-6 z-50 px-4 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-white/20 text-white font-['Outfit',sans-serif] text-sm backdrop-blur-md transition-all shadow-lg cursor-pointer flex items-center gap-2 group"
      title="Toggle Language"
    >
      <svg className="w-4 h-4 text-slate-300 group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
      </svg>
      <span>{i18n.language === 'en' ? 'English' : '日本語'}</span>
    </button>
  );
}
