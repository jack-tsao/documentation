import { useState } from 'react';
import axios from 'axios';
import API_ROUTES from '../utilities/api';

function CameraCapture() {
    const [selectedImage, setSelectedImage] = useState(null); 
    const [result, setResult] = useState('');
    const [error, setError] = useState('');

    const handleAnalyze = (imageFile, prompt) => {
        const formData = new FormData()
        formData.append("image", imageFile)
        formData.append("prompt", prompt)
        //formData.append("language", language)

        const response = axios.post(API_ROUTES.ANALYZE, formData)
            .then((res)=>{
                console.log("AI Result", res.data);
                setResult(res.data.answer);
            })
            .catch((err)=>{
                console.log("Analyze Failed:", err);
                setError("AI Failed");
            })
    }

    const handleClick = ()=> {
        setSelectedImage('XXX')
        console.log(selectedImage)
    }

    return (
        <div className=''>
            <div>
                <video></video>
            </div>
            <div>
                <button>open</button>
                <button onClick={handleClick}>capture</button>
                <button>close</button>
            </div>
        </div>
    )
}

export default CameraCapture;