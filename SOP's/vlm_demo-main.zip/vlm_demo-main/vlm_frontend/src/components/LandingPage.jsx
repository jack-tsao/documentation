import React from "react";
import DarkVeil from "./DarkVeil";
import BorderGlow from "./BorderGlow";
import "./LandingPage.css";

export default function LandingPage({ onStart }) {
  return (
    <div className="landing-container">
      {/* Animated ambient background */}
      <div className="darkveil-container" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0 }}>
        <DarkVeil speed={0.3} noiseIntensity={0.05} />
      </div>
      <div className="color-overlay" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', background: 'linear-gradient(135deg, rgba(0,66,113,0.85) 0%, rgba(107,33,168,0.85) 100%)', mixBlendMode: 'color', zIndex: 1, pointerEvents: 'none' }}></div>
      <div className="color-overlay-darken" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', background: '#000', opacity: 0.3, mixBlendMode: 'multiply', zIndex: 2, pointerEvents: 'none' }}></div>

      <nav className="landing-nav">
        <span className="landing-logo">Advantech</span>
      </nav>

      <main className="landing-main">
        <div className="landing-hero">
          <h1 className="landing-headline">
            Enabling an<br/><span>Intelligent</span> Planet
          </h1>
          <div className="cta-container">
            <div onClick={onStart} style={{ cursor: 'pointer' }}>
              <BorderGlow
                edgeSensitivity={60}
                glowColor="270 80 60"
                backgroundColor="transparent"
                borderRadius={9999}
                glowRadius={30}
                glowIntensity={1.5}
                animated={true}
                colors={['#6b21a8', '#004271', '#38bdf8']}
              >
                <div className="landing-cta" style={{ border: 'none', background: 'transparent' }}>
                  <span className="cta-text">Try it</span>
                </div>
              </BorderGlow>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
