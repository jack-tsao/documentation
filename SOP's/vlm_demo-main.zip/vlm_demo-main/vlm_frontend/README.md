# VLM Frontend

This directory contains the React/Vite frontend for the VLM Chat Interface.

---

## Website Brand and Design Philosophy

### Our Mission
To bridge the gap between advanced Vision-Language Models (VLM) and human operators through an intuitive, real-time, and immersive interface. We aim to empower users—from analysts to field operators—to interact seamlessly with visual AI, unlocking critical insights from live video streams and imagery without technical friction.

### Company Theme: "Intelligent Overwatch"
The core theme of the platform revolves around "Intelligent Overwatch." The interface is designed to act as a high-tech command center. Whether the user is connecting to a live drone feed or analyzing uploaded footage, the system is meant to feel like an extension of their perception—sharp, focused, and always online.

### Design Style & Aesthetic
We chose a **Modern Glassmorphism & Cyber-Functional** aesthetic. 
- **Dark-Mode First:** The default deep slate and black backgrounds reduce eye strain during prolonged monitoring sessions. Crucially, this dark canvas makes the vibrant, color-coded AI bounding boxes and status alerts pop instantly.
- **Ethereal Visuals (WebGL):** The inclusion of subtle, flowing aurora effects and glowing borders isn't just for show. It represents the "living" AI running in the background—a visual metaphor for neural networks actively processing and analyzing data.
- **Clean Typography:** By relying on *Outfit* for critical status indicators and *Inter* for general readability, we balance stark, utilitarian legibility with a polished, next-generation tech feel.

### Why We Made It Look This Way
1. **Focus on the Feed:** The design deliberately strips away heavy, opaque sidebars and bulky navigation. By using semi-transparent floating action buttons and glowing edges, the user's attention is naturally drawn to the center of the screen: the media player and the AI's real-time detections.
2. **Immediate State Recognition:** We utilized distinct, semantic color coding (Emerald Green for "Online/Drone Feed", Crimson Red for "Standby/Upload Prompt") to ensure that operators know the exact status of their connection and AI model at a single glance, even in their peripheral vision.
3. **Global Readiness:** The upfront inclusion of a localized language switcher (English/Japanese) reflects our commitment to international operations and accessibility. It ensures that the interface feels globally ready without burying options in settings menus.
4. **Frictionless Interaction:** The use of clean, universally understood iconography (clouds for uploads, slashed cameras for canceling feeds) instead of text-heavy buttons significantly reduces cognitive load. It creates a tactile, dashboard-like experience that feels highly responsive.

---

## Front End Design & Architecture

### Core Ideology
The frontend is designed to be a highly interactive, immersive, and responsive interface for Vision-Language Model (VLM) operations. Key design principles include:
- **Immersive Visuals:** Utilizing WebGL and advanced CSS animations to create dynamic backgrounds (`SoftAurora`, `DarkVeil`, `BorderGlow`) that react and set the mood for AI interactions.
- **Video & Media Centric:** The interface revolves around uploading and streaming media. The core media components act as the centerpiece, providing real-time feedback with bounding boxes for object detection.
- **Accessibility & Globalization:** Built-in multi-language support (English and Japanese) allows broader usability without reloading the application.
- **Modern UI Patterns:** Incorporates intuitive controls like a media playback toolbar (play/pause, skip), dark/light mode toggling, clear chat functionalities, and clean floating action buttons.

### Technology Stack & Libraries

#### 1. Framework
- **React 19:** The core UI framework, leveraging modern hooks (`useState`, `useEffect`, `useRef`) for robust and predictable state management.
- **Vite:** Used as the build tool and development server, ensuring fast Hot Module Replacement (HMR) and optimized production builds.

#### 2. Styling & Visual Effects
- **Tailwind CSS:** Utilized via comprehensive utility classes for rapid UI development, ensuring responsive and modern styling directly within React components.
- **OGL (`ogl`):** A minimal WebGL library utilized for rendering high-performance background effects (e.g., auroras and glowing elements), making the AI chat interface visually stunning without sacrificing performance.

#### 3. Internationalization (i18n)
- **i18next & react-i18next:** Manage translations across the application. The interface translates dynamic model responses on-the-fly via the backend, while static UI elements are toggled using the built-in language switcher.

#### 4. Networking
- **Axios / Fetch API:** Handles communication with the backend APIs (`/analyze`, `/model-status`, `/translate`, etc.) for seamless asynchronous data fetching, model control, and inference.

---

## Front End Implementation

### Directory Structure
The frontend application is contained within the `src/` directory:
- `components/`: Modular React components forming the UI (e.g., `CameraCapture`, `LandingPage`, WebGL effects).
- `utilities/`: Helper scripts, including `api.jsx` for managing endpoint routes.
- `App.jsx`: The main application entry point and global state manager.
- `i18n.js`: Configuration for language translation settings.
- `index.css`: Global styles and utility configurations.

### Core Workflows

#### 1. Application State & Entry (`App.jsx`)
`App.jsx` acts as the primary orchestrator. It manages:
- **Media Handling:** Manages the state of the active video stream or uploaded file. It provides the mechanisms to track video timestamps and coordinate with the AI detection overlays.
- **Theme & Language:** Tracks dark/light mode states and integrates with `react-i18next` to switch locales dynamically.
- **Translations:** A custom utility `translateTextOnTheFly` fetches localized strings from the backend when dynamic AI output needs translation.
- **Model Lifecycle:** Tracks model load states, providing UI controls to trigger model loading or unloading to efficiently manage GPU VRAM.

#### 2. Video Playback & Overlays (`CameraFeed`)
The video player component handles all media playback logic.
- It uses a `<video>` ref to manually control play/pause states and skip functionality.
- **Detections Sync:** Bounding boxes and object detection results returned by the VLM are overlaid onto the video. The component dynamically filters the `detections` array based on the active frame's timestamp (e.g., matching detections within a 1.0-second delta of the `videoTime`).

#### 3. API Communication (`api.jsx`)
All backend interactions are centralized in `api.jsx`. The API base URL points to the local backend service (`http://localhost:8000/vlm`).
Key routes include:
- `MODEL_STATUS`: Polls the active status of the VLM.
- `ANALYZE`: Sends image/video data combined with user text prompts for AI inference.
- `LOAD` / `UNLOAD`: Triggers model loading into memory or purging to clear VRAM.
- `TRANSLATE`: Invokes the backend translation service.

#### 4. Background Effects (WebGL)
WebGL components like `SoftAurora.jsx` and `BorderGlow.jsx` utilize the `ogl` library to attach shader programs to canvas elements. 
- These components handle their own render loops via `requestAnimationFrame`.
- They update uniform variables (like time and resolution) independently to ensure smooth, 60fps animations without blocking the main React render cycle.
